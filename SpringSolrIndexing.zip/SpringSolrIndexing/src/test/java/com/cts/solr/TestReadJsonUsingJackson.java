package com.cts.solr;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;

import com.cts.solr.entity.Iris;
import com.cts.solr.readJson.ReadJsonUsingJackson;
import com.cts.solr.readproperties.JsonProperties;
import com.fasterxml.jackson.databind.JsonMappingException;

//@TestPropertySource
//@ContextConfiguration(classes = ReadJsonUsingJackson.class)
//@SpringBootTest(classes=ReadJsonUsingJackson.class)
class TestReadJsonUsingJackson {

	JsonProperties jsonProperties = mock(JsonProperties.class);
	ReadJsonUsingJackson readJson=new ReadJsonUsingJackson(jsonProperties);
	
	public Location loac;
	
//	@Autowired
//	JsonProperties JsonProperties;
//	
//	JsonProperties jsonProperties2=new JsonProperties();
//	@MockBean
//	ReadJsonUsingJackson readJson;
//	@MockBean
//	private JsonProperties jsonProperties;
	
//	@Value("${json.fileinputstream}")
//	public String location;
	
	@Test
	void test() throws Throwable, JsonMappingException, IOException {
		
		Mockito.when(jsonProperties.getFileinputstream()).thenReturn("E://Datasets//iris.json"); 
		List<Iris> readJsonFile = readJson.ReadJsonFile();
		
		assertEquals(Iris.class, readJsonFile.get(0).getClass());
	}

}
