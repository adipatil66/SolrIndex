package com.cts.solr.controller;

import java.io.IOException;
import java.util.List;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrServerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.solr.entity.Iris;
import com.cts.solr.services.Solr_Client;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@RestController
@RequestMapping("/api")
public class SolrIndex {

	
	@Autowired
	Solr_Client SolrCli; 
	
	@GetMapping("/index")
	public void IndexJsonFile(List<Iris> iriss) throws JsonParseException, JsonMappingException, IOException, SolrServerException {

		Logger logger = LoggerFactory.getLogger(SolrIndex.class);
		
		//SolrClient Solr = new HttpSolrClient.Builder().build();
		SolrClient Solr=SolrCli.CreateClient();

//		Solr.add(doc);
		for(Iris i: iriss) {

			Solr.addBean(i);
		}
		
		// Saving the changes
		Solr.commit();
		
		//implement logs for this project
		//System.out.println("Documents added");
		logger.info("Documents Uploaded");

	   }
	
}
