package com.cts.solr;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.solr.client.solrj.SolrServerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import com.cts.solr.entity.Iris;
import com.cts.solr.readJson.ReadJsonUsingJackson;
import com.cts.solr.readproperties.JsonProperties;
import com.cts.solr.controller.SolrIndex;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class SpringsolrApplication {

	@Autowired
	ReadJsonUsingJackson readJson;
	
	@Autowired
	SolrIndex Si;
	
	
	public static void main(String[] args) throws SolrServerException, IOException {
		ConfigurableApplicationContext context = SpringApplication.run(SpringsolrApplication.class, args);
		
	}
	
	@PostConstruct
	public void CreateClient() throws JsonParseException, JsonMappingException, IOException, SolrServerException {
		
		List<Iris> iriss=readJson.ReadJsonFile();
		System.out.println(iriss.getClass());
		
		Si.IndexJsonFile(iriss);
		
	}
}
