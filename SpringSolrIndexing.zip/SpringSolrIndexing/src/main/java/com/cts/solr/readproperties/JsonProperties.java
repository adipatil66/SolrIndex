package com.cts.solr.readproperties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value="prototype")
@ConfigurationProperties(prefix="json")
public class JsonProperties {

	private String fileinputstream ;

	public JsonProperties(String fileinputstream) {
		super();
		this.fileinputstream = fileinputstream;
	}

	public JsonProperties() {
		// TODO Auto-generated constructor stub
	}

	public String getFileinputstream() {
		return fileinputstream;
	}

	public void setFileinputstream(String fileinputstream) {
		this.fileinputstream = fileinputstream;
	}
	
}
