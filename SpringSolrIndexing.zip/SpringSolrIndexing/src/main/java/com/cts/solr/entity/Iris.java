package com.cts.solr.entity;

import org.apache.solr.client.solrj.beans.Field;

public class Iris {

	@Field
	private String species;
	@Field
	private float sepalLength;
	@Field
	private float sepalWidth;
	@Field
	private float petalLength;
	@Field
	private float petalWidth;

	public float getSepalLength() {
		return sepalLength;
	}

	public void setSepalLength(float sepalLength) {
		this.sepalLength = sepalLength;
	}

	public float getSepalWidth() {
		return sepalWidth;
	}

	public void setSepalWidth(float sepalWidth) {
		this.sepalWidth = sepalWidth;
	}

	public float getPetalLength() {
		return petalLength;
	}

	public void setPetalLength(float petalLength) {
		this.petalLength = petalLength;
	}

	public float getPetalWidth() {
		return petalWidth;
	}

	public void setPetalWidth(float petalWidth) {
		this.petalWidth = petalWidth;
	}

	public String getSpecies() {
		return species;
	}

	public void setSpecies(String species) {
		this.species = species;
	}

	@Override
	public String toString() {
		return "Iris [species=" + species + ", sepalLength=" + sepalLength + ", sepalWidth=" + sepalWidth
				+ ", petalLength=" + petalLength + ", petalWidth=" + petalWidth + "]";
	}
	
}
