package com.cts.solr.readJson;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.solr.entity.Iris;
import com.cts.solr.readproperties.JsonProperties;
import com.cts.solr.readproperties.SolrProperties;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ReadJsonUsingJackson {

	@Autowired
	JsonProperties JsonProperties;

	public List<Iris> ReadJsonFile() throws JsonParseException, JsonMappingException, IOException {
		
			ObjectMapper mapper =new ObjectMapper();
			// Do not hardcode 
			String fileLoc= JsonProperties.getFileinputstream();
			System.out.println(fileLoc);
			InputStream inputstream =new FileInputStream(new File(fileLoc));
			TypeReference<List<Iris>> typeRefrence = new TypeReference<List<Iris>>() {};
			List<Iris> iriss= mapper.readValue(inputstream,typeRefrence);
			
//			System.out.println(iriss);
			
			return iriss;
	}
	
	public ReadJsonUsingJackson(com.cts.solr.readproperties.JsonProperties jsonProperties) {
		super();
		JsonProperties = jsonProperties;
	}
}



